﻿using LoanValidatorApp.Helpers;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoanValidator2019
{
    public partial class MainForm : Form
    {
        private readonly ApiService _apiService;

        public MainForm()
        {
            InitializeComponent();
          ;

            _apiService = new ApiService();
          //  txtFilePath.Text = "C:\\Users\\Hp\\Downloads\\Modified_Mortgage.xlsx";
    //        txtJSON.Text = @"{
    //""accountNumber"": ""0024006887"",
    //""accountHolderMemberNumber"": ""003179704"",
    //""accountHolderName"": ""ELVIN Y OHANESIAN"",
    //""jointHolderMemberNumber"": """",
    //""jointHolderName"": """",
    //""openDate"": ""2024-08-28"",
    //""accountType"": ""Home Loan"",
    //""accountSubType"": ""FIXED SECOND MTG"",
    //""accruedLateChargeBalance"": 0.0,
    //""currentBalance"": 74820.26,
    //""escrowBalance"": 0.0,
    //""interestRate"": 7.875,
    //""maturityDate"": ""2044-09-01"",
    //""originalLoanTerm"": 240,
    //""originalLoanAmount"": 75700.0,
    //""paymentAccidentHealthAmount"": 0.0,
    //""paymentBuydownSubsidyAmount"": 0.0,
    //""paymentCountyTaxAmount"": 0.0,
    //""paymentHazardAmount"": 0.0,
    //""paymentHudSubsidyAmount"": 0.0,
    //""paymentLienAmount"": 0.0,
    //""paymentLifeAmount"": 0.0,
    //""paymentMiscellaneousAmount"": 0.0,
    //""paymentMortgageInsuranceAmount"": 0.0,
    //""paymentNextDueDate"": ""2025-03-01"",
    //""paymentPrincipalAndInterest"": 627.31,
    //""paymentTotalAmountDue"": 627.31,
    //""pointsPaid"": 0.0,
    //""previousPaymentEscrowAmount"": 0.0,
    //""previousPaymentInterestAmount"": 492.04,
    //""previousPaymentPrincipalAmount"": 157.96,
    //""previousPaymentReceivedDate"": ""2025-01-15"",
    //""previousPaymentTotalAmount"": 627.31,
    //""previousYearInterestOnEscrow"": 0.0,
    //""previousYearInterestPaid"": 2046.77,
    //""previousYearPrincipalPaid"": 516.37,
    //""previousYearTaxesPaid"": 0.0,
    //""propertyType"": ""SF"",
    //""remainingLoanTerm"": 235,
    //""statusCode"": ""Active"",
    //""statusDescription"": ""No paid in full stop"",
    //""ytdHazardInsurancePaid"": 0.0,
    //""ytdInterestAssessed"": 0.0,
    //""ytdInterestPaidAmount"": 492.04,
    //""ytdPrincipalPaidAmount"": 157.96,
    //""ytdMortgageInsuranceAmount"": 0.0
    //}";
        }

        private async void btnProcess_Click(object sender, EventArgs e)
        {
            try
            {
                btnProcess.Enabled = false; // Disable button during processing

                // Fetch UI values before running in background
                string filePath = txtFilePath.Text;
              

                UpdateStatus("Authenticating...");

                await Task.Run(() => ProcessLoansAsync(filePath));

                UpdateStatus("Process completed!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
                UpdateStatus("Error occurred");
            }
            finally
            {
                btnProcess.Enabled = true; // Re-enable button
            }
        }

        // Runs in the background
        private async Task ProcessLoansAsync(string filePath)
        {
            UpdateStatus("Reading Excel file...");
            var loanNumbers = ExcelHelper.GetLoanNumbers(filePath);
            UpdateStatus("Setting up Credentails Excel file...");
            await _apiService.GetAccessTokenAsync();
            foreach (var loanNumber in loanNumbers)
            {
                // if (loanNumber != "0023048690") continue;
                UpdateStatus($"Processing {loanNumber}...");
                var jsonData = await _apiService.GetLoanInfoAsync(loanNumber);//      //GetUIText(txtJSON); // Get text safely

                UpdateStatus($"Downloaded {loanNumber} Data.");
                if (!ExcelHelper.LoanSheetExists(filePath, loanNumber))
                {
                    ExcelHelper.UpdateLoanStatus(filePath, loanNumber, false);
                    continue;
                }

                var expectedValues = ExcelHelper.GetFieldsAndMspValues(filePath, loanNumber);
                var validationResults = ValidationService.ValidateLoanData(jsonData, expectedValues);

                bool allMatched = validationResults.All(v => v.IsMatched);
                ExcelHelper.UpdateLoanStatus(filePath, loanNumber, allMatched);
                ExcelHelper.UpdateValidationResults(filePath, loanNumber, validationResults);
            }
        }

        // Safely gets text from UI control
        private string GetUIText(RichTextBox textBox)
        {
            if (textBox.InvokeRequired)
            {
                return (string)textBox.Invoke(new Func<string>(() => textBox.Text));
            }
            return textBox.Text;
        }

        // Safely updates UI status
        private void UpdateStatus(string message)
        {
            if (lblStatus.InvokeRequired)
            {
                lblStatus.Invoke(new Action(() => lblStatus.Text = message));
            }
            else
            {
                lblStatus.Text = message;
            }
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "Excel Files|*.xlsx";

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    txtFilePath.Text = openFileDialog.FileName;
                }
            }
        }

    }
}

