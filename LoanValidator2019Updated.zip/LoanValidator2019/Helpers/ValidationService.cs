﻿using LoanValidatorApp.Models;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text.RegularExpressions;

namespace LoanValidatorApp.Helpers
{
    public static class ValidationService
    {

        public static string GetOnlyNumbersAndDecimal(string input)
        {
            return Regex.Replace(input, @"[^0-9.]", ""); // Removes everything except numbers and decimal
        }
        public static List<LoanDataValidationResult> ValidateLoanData(LoanData apiResponse, Dictionary<string, string> expectedValues)
        {
            var apiDict = JObject.FromObject(apiResponse);
            var results = new List<LoanDataValidationResult>();

            foreach (var kvp in expectedValues)
            {
                string apiPropertyName = kvp.Key;
                string expectedValue = kvp.Value?.Trim(); // Trim expected value

                

                // Handle "N/A" or "none" case
                if (string.Equals(expectedValue, "N/A", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(expectedValue, "none", StringComparison.OrdinalIgnoreCase))
                {
                    expectedValue = null;
                }

                // Get API value
                string apiValue = apiDict[apiPropertyName]?.ToString()?.Trim(); // Trim API value

                // If column is blank and API value is "0", treat it as a match
                if (string.IsNullOrEmpty(expectedValue) && apiValue == "0")
                    expectedValue = "0";

                // Normalize values
                if (!apiPropertyName.ToLower().Contains("date")) { 
                    expectedValue = NormalizeNumber(expectedValue);
                    apiValue = NormalizeNumber(apiValue);
                }

                if (apiPropertyName.ToLower() == "originalLoanTerm" || apiPropertyName.ToLower() =="remainingLoanTerm") {
                    expectedValue = GetOnlyNumbersAndDecimal(expectedValue);
                }


                // Add condition to handle "N/A", "none", or null expectedValue with empty API value
                if ((string.IsNullOrEmpty(expectedValue) || expectedValue == "N/A" || expectedValue == "none" || expectedValue == "0.00" || expectedValue == "0.0" || expectedValue == "0") && string.IsNullOrEmpty(apiValue))
                {
                    expectedValue = string.Empty;
                    apiValue = string.Empty;
                }

                // Compare values
                bool isMatched = string.Equals(apiValue, expectedValue, StringComparison.OrdinalIgnoreCase);

                // Add to results
                results.Add(new LoanDataValidationResult
                {
                    ColumnName = apiPropertyName,
                    MSPValue = expectedValue,
                    APIValue = apiValue,
                    IsMatched = isMatched
                });
            }

            return results;
        }

        // Helper method to normalize numeric values
        private static string NormalizeNumber(string value)
        {
            if (string.IsNullOrEmpty(value)) return value;

            // Remove currency symbols, commas, and leading zeros
            value = Regex.Replace(value, @"[$,]", "").TrimStart('0');

            // If numeric, format it consistently
            if (decimal.TryParse(value, out decimal number))
            {
                return number.ToString("0.##"); // Removes trailing zeros after decimal
            }

            return value;
        }



        private static JToken GetValue(JObject obj, string key)
        {
            foreach (var prop in obj.Properties())
            {
                if (prop.Name.Equals(key, System.StringComparison.OrdinalIgnoreCase))
                    return prop.Value;
            }
            return null;
        }
    }
}