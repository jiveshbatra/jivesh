﻿using LoanValidatorApp.Helpers;
using LoanValidatorApp.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace LoanValidator2019.Helpers
{
    public class ProcessHelper
    {
        private readonly ApiService _apiService;
        private readonly string _StaticJSONData;
        private readonly bool _isDevelopment;

        public ProcessHelper(bool isDevelopment, ApiService apiService, string StaticJSONData)
        {
            _apiService = apiService;
            _isDevelopment = isDevelopment;
            _StaticJSONData = StaticJSONData;
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
        }

        public async Task ProcessExcelFileAsync(string filePath)
        {
            FileInfo fileInfo = new FileInfo(filePath);
            using (ExcelPackage package = new ExcelPackage(fileInfo))
            {
                if (!_isDevelopment)
                {
                    await _apiService.GetAccessTokenAsync();
                }

                ExcelWorksheet inputSheet = package.Workbook.Worksheets["BulkAutomatedTester"];
                ExcelWorksheet outputSheet = package.Workbook.Worksheets["output"] ?? package.Workbook.Worksheets.Add("output");
                outputSheet.Cells.Clear();
                // Insert "Pass/Fail" as the first column in the output sheet
                outputSheet.Cells[1, 1].Value = "Pass/Fail";

                for (int col = 1; col <= inputSheet.Dimension.End.Column; col++)
                {
                    // Shift the existing headers one column to the right
                    outputSheet.Cells[1, col + 1].Value = inputSheet.Cells[1, col].Value;
                }

                int outputRow = 2;
                for (int row = 2; row <= inputSheet.Dimension.End.Row; row++)
                {
                    var rowData = ReadRowData(inputSheet, row);
                    string cleanedLoanNumber = ExtractLoanNumber(rowData["LoanNumber"]);

                    LoanData apiData = _isDevelopment
                        ? JsonConvert.DeserializeObject<LoanData>(_StaticJSONData)
                        : await _apiService.GetLoanInfoAsync(cleanedLoanNumber);

                    WriteRow(outputSheet, outputRow++, rowData);
                    rowData["Field"] = "Api test results";
                    WriteApiDataRow(outputSheet, outputRow++, apiData, rowData);
                    WriteMismatchRow(outputSheet, outputRow++, rowData, apiData);
                }
                ApplyFormatting(outputSheet);
                package.Save();
            }
        }

        private Dictionary<string, string> ReadRowData(ExcelWorksheet sheet, int row)
        {
            var data = new Dictionary<string, string>();
            for (int col = 1; col <= sheet.Dimension.End.Column; col++)
            {
                string header = sheet.Cells[1, col].Text.Replace(" ","");
                string value = sheet.Cells[row, col].Text;
                data[header] = value;
            }
            return data;
        }

        private string ExtractLoanNumber(string loanNumber)
        {
            return new string(loanNumber.Where(char.IsDigit).ToArray()).TrimStart('0');
        }

        private void WriteRow(ExcelWorksheet sheet, int row, Dictionary<string, string> rowData)
        {
            int col = 2;
            foreach (var kvp in rowData)
            {
                sheet.Cells[row, col++].Value =  kvp.Value;
            }
        }

        private static string ConvertToStandardDateFormat(string apiPropertyName, string input)
        {
            if (string.IsNullOrWhiteSpace(input)) return input; // Keep null/empty values as-is
            if (!apiPropertyName.ToLower().Contains("date")) return input;

            // Try parsing as a numeric serial date (Excel format)
            if (double.TryParse(input, out double serialDate))
            {
                if (serialDate >= 1 && serialDate <= 2958465)
                {
                    return DateTime.FromOADate(serialDate).ToString("yyyy-MM-dd");
                }
                else
                {
                    return input;
                }
            }

            // Try parsing common date formats
            string[] dateFormats = { "M/d/yyyy", "M/dd/yyyy", "MM/d/yyyy", "MM/dd/yyyy" };
            DateTime parsedDate;

            if (DateTime.TryParseExact(input, dateFormats, CultureInfo.InvariantCulture, DateTimeStyles.None, out parsedDate))
            {
                return parsedDate.ToString("yyyy-MM-dd"); // Convert to ISO format
            }

            return input; // Return as-is if it's not a recognizable date
        }

        private void WriteApiDataRow(ExcelWorksheet sheet, int row, LoanData apiData, Dictionary<string, string> rowData)
        {
            int col = 2;
            foreach (var kvp in rowData)
            {
                string apiValue = GetApiValue(kvp.Key, apiData);
                sheet.Cells[row, col++].Value = apiValue;
            }
            sheet.Cells[row, 4].Value = "Api test results"; // Fir Field Update

        }

        private void WriteMismatchRow(ExcelWorksheet sheet, int row, Dictionary<string, string> rowData, LoanData apiData)
        {
            var validationResults = ValidateLoanData(apiData, rowData);
            int col = 2;
            
            bool isRowMatched = validationResults.All(v => v.IsMatched);

            foreach (var result in validationResults)
            {
                if (!result.IsMatched) {
                    sheet.Cells[row, col].Value = GetMismatchMessage(result.MSPValue,result.APIValue);
                    sheet.Cells[row, col].Style.Font.Color.SetColor(Color.Red); //  Row  Color Should Show as Red
                }
                sheet.Cells[row -1, col].Style.Font.Color.SetColor(result.IsMatched ? Color.Green : Color.Red); // previous Row  Color Should Show as Red
                col++;
            }

            sheet.Cells[row - 2, 1].Value = isRowMatched ? "Pass" : "Fail";
            sheet.Cells[row - 2, 1].Style.Font.Color.SetColor(isRowMatched?Color.Green: Color.Red);


            for (int i = 1; i <= 3; i++) // merge the start 3 columns
            {
                var col1Range = sheet.Cells[row - 2, i, row, i];
                col1Range.Merge = true;
                col1Range.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                col1Range.Style.VerticalAlignment = ExcelVerticalAlignment.Center;
            }
         


            sheet.Cells[row, 4].Value = "Note";
        }


        private string GetMismatchMessage(string mspValue, string apiValue)
        {
            if (string.IsNullOrEmpty(apiValue) && !string.IsNullOrEmpty(mspValue))
                return $"API value is missing, expected {mspValue}.";

            if (!string.IsNullOrEmpty(apiValue) && string.IsNullOrEmpty(mspValue))
                return $"Expected value is missing, but API returned {apiValue}.";

            if (DateTime.TryParse(apiValue, out DateTime apiDate) && DateTime.TryParse(mspValue, out DateTime mspDate))
            {
                if (apiDate != mspDate)
                    return $"Date mismatch: Expected {mspDate:yyyy-MM-dd}, but got {apiDate:yyyy-MM-dd}.";
            }

            if (apiValue != mspValue)
            {
                if (decimal.TryParse(apiValue, out decimal apiNum) && decimal.TryParse(mspValue, out decimal mspNum))
                {
                    if (apiNum > mspNum)
                        return $"API value {apiNum} is greater than expected {mspNum}.";
                    if (apiNum < mspNum)
                        return $"API value {apiNum} is less than expected {mspNum}.";
                }

                if (bool.TryParse(apiValue, out bool apiBool) && bool.TryParse(mspValue, out bool mspBool))
                {
                    if (apiBool != mspBool)
                        return $"Boolean mismatch: Expected {mspBool}, but got {apiBool}.";
                }

                if (apiValue.Trim().ToLower() == "null" || mspValue.Trim().ToLower() == "null")
                    return $"Null value mismatch: One of the values is null.";

                return $"Mismatch: Expected {mspValue}, but got {apiValue}.";
            }

            return "Values match.";
        }


        private string GetApiValue(string columnName, LoanData apiData)
        {
            if (apiData == null) return "";

            // Normalize the column name using the mapping dictionary
            if (!ExcelHelper.ColumnMapping.TryGetValue(columnName, out string mappedPropertyName))
            {
                mappedPropertyName = columnName; // If not mapped, use the original column name
            }

            // Convert LoanData properties to a case-insensitive dictionary
            var apiDict = typeof(LoanData)
                .GetProperties()
                .ToDictionary(p => p.Name.ToLower(), p => p.GetValue(apiData)?.ToString() ?? "");

            // Lookup the mapped property in a case-insensitive manner
            apiDict.TryGetValue(mappedPropertyName.ToLower(), out string apiValue);

            return apiValue ?? "";
        }


        public static string GetOnlyNumbersAndDecimal(string input)
        {
            return Regex.Replace(input, @"[^0-9.]", "");
        }
        private static string GetMappedApiPropertyName(string field)
        {
            field = field.Replace(" ", "");
            return ExcelHelper.ColumnMapping.TryGetValue(field, out string apiPropertyName)
                ? apiPropertyName
                : field;
        }
        public static List<LoanDataValidationResult> ValidateLoanData(LoanData apiResponse, Dictionary<string, string> expectedValues)
        {
            var apiDict = JObject.FromObject(apiResponse);
            var results = new List<LoanDataValidationResult>();

            foreach (var kvp in expectedValues)
            {
                string apiPropertyName = kvp.Key;
                string expectedValue = kvp.Value?.Trim();

                if (string.Equals(expectedValue, "N/A", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(expectedValue, "none", StringComparison.OrdinalIgnoreCase))
                {
                    expectedValue = null;
                }

                string apiValue = apiDict[GetMappedApiPropertyName(apiPropertyName)]?.ToString()?.Trim();

                if (string.IsNullOrEmpty(expectedValue) && apiValue == "0")
                    expectedValue = "0";

                if (!apiPropertyName.ToLower().Contains("date"))
                {
                    expectedValue = NormalizeNumber(expectedValue);
                    apiValue = NormalizeNumber(apiValue);
                }
                else{
                    expectedValue = ConvertToStandardDateFormat(apiPropertyName, expectedValue);
                }

                if (apiPropertyName.ToLower() == "originalloanterm" || apiPropertyName.ToLower() == "remainingloanterm")
                {
                    expectedValue = GetOnlyNumbersAndDecimal(expectedValue);
                }

                if ((string.IsNullOrEmpty(expectedValue) || expectedValue == "0.00" || expectedValue == "0" || apiPropertyName.ToLower() == "cifnumber" || apiPropertyName.ToLower() == "loannumber" || apiPropertyName.ToLower() == "field" ) && string.IsNullOrEmpty(apiValue))
                {
                    expectedValue = string.Empty;
                    apiValue = string.Empty;
                }

                bool isMatched = string.Equals(apiValue, expectedValue, StringComparison.OrdinalIgnoreCase);

                results.Add(new LoanDataValidationResult
                {
                    ColumnName = apiPropertyName,
                    MSPValue = expectedValue,
                    APIValue = apiValue,
                    IsMatched = isMatched
                });
            }

            return results;
        }

        private static string NormalizeNumber(string value)
        {
            if (string.IsNullOrEmpty(value)) return value;

            value = Regex.Replace(value, @"[$,]", "").TrimStart('0');

            if (decimal.TryParse(value, out decimal number))
            {
                return number.ToString("0.##");
            }

            return value;
        }

        private static void ApplyFormatting(ExcelWorksheet sheet)
        {
            using (var range = sheet.Cells[1, 1, sheet.Dimension.End.Row, sheet.Dimension.End.Column])
            {
                range.AutoFitColumns();
                range.Style.Font.Size = 11;
                range.Style.Font.Name = "Calibri";
                range.Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                range.Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                range.Style.Border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                range.Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
            }

            using (var headerRange = sheet.Cells[1, 1, 1, sheet.Dimension.End.Column])
            {
                headerRange.Style.Font.Bold = true;
                headerRange.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                headerRange.Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.LightGray);
            }
        }
    }
}
