﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoanValidatorApp.Models
{
    
    public class LoanData
    {
        [JsonProperty("accountNumber")]
        public string AccountNumber { get; set; }

        [JsonProperty("accountHolderMemberNumber")]
        public string AccountHolderMemberNumber { get; set; }

        [JsonProperty("accountHolderName")]
        public string AccountHolderName { get; set; }

        [JsonProperty("jointHolderMemberNumber")]
        public string JointHolderMemberNumber { get; set; }

        [JsonProperty("jointHolderName")]
        public string JointHolderName { get; set; }

        [JsonProperty("openDate")]
        public string OpenDate { get; set; }

        [JsonProperty("accountType")]
        public string AccountType { get; set; }

        [JsonProperty("accountSubType")]
        public string AccountSubType { get; set; }

        [JsonProperty("accruedLateChargeBalance")]
        public double? AccruedLateChargeBalance { get; set; }

        [JsonProperty("currentBalance")]
        public double? CurrentBalance { get; set; }

        [JsonProperty("escrowBalance")]
        public double? EscrowBalance { get; set; }

        [JsonProperty("interestRate")]
        public double? InterestRate { get; set; }

        [JsonProperty("maturityDate")]
        public string MaturityDate { get; set; }

        [JsonProperty("originalLoanTerm")]
        public int OriginalLoanTerm { get; set; }

        [JsonProperty("originalLoanAmount")]
        public double? OriginalLoanAmount { get; set; }

        [JsonProperty("paymentAccidentHealthAmount")]
        public double? PaymentAccidentHealthAmount { get; set; }

        [JsonProperty("paymentBuydownSubsidyAmount")]
        public double? PaymentBuydownSubsidyAmount { get; set; }

        [JsonProperty("paymentCountyTaxAmount")]
        public double? PaymentCountyTaxAmount { get; set; }

        [JsonProperty("paymentHazardAmount")]
        public double? PaymentHazardAmount { get; set; }

        [JsonProperty("paymentHudSubsidyAmount")]
        public double? PaymentHudSubsidyAmount { get; set; }

        [JsonProperty("paymentLienAmount")]
        public double? PaymentLienAmount { get; set; }

        [JsonProperty("paymentLifeAmount")]
        public double? PaymentLifeAmount { get; set; }

        [JsonProperty("paymentMiscellaneousAmount")]
        public double? PaymentMiscellaneousAmount { get; set; }

        [JsonProperty("paymentMortgageInsuranceAmount")]
        public double? PaymentMortgageInsuranceAmount { get; set; }


        [JsonProperty("paymentNextDueDate")]
        public string PaymentNextDueDate { get; set; }

        [JsonProperty("paymentPrincipalAndInterest")]
        public double? PaymentPrincipalAndInterest { get; set; }

        [JsonProperty("paymentTotalAmountDue")]
        public double? PaymentTotalAmountDue { get; set; }

        [JsonProperty("pointsPaid")]
        public double? PointsPaid { get; set; }

        [JsonProperty("previousPaymentEscrowAmount")]
        public double? PreviousPaymentEscrowAmount { get; set; }

        [JsonProperty("previousPaymentInterestAmount")]
        public double? PreviousPaymentInterestAmount { get; set; }

        [JsonProperty("previousPaymentPrincipalAmount")]
        public double? PreviousPaymentPrincipalAmount { get; set; }

        [JsonProperty("previousPaymentReceivedDate")]
        public string PreviousPaymentReceivedDate { get; set; }

        [JsonProperty("previousPaymentTotalAmount")]
        public double? PreviousPaymentTotalAmount { get; set; }

        [JsonProperty("previousYearInterestOnEscrow")]
        public double? PreviousYearInterestOnEscrow { get; set; }

        [JsonProperty("previousYearInterestPaid")]
        public double? PreviousYearInterestPaid { get; set; }

        [JsonProperty("previousYearPrincipalPaid")]
        public double? PreviousYearPrincipalPaid { get; set; }

        [JsonProperty("previousYearTaxesPaid")]
        public double? PreviousYearTaxesPaid { get; set; }

        [JsonProperty("propertyType")]
        public string PropertyType { get; set; }

        [JsonProperty("remainingLoanTerm")]
        public int RemainingLoanTerm { get; set; }

        [JsonProperty("statusCode")]
        public string StatusCode { get; set; }

        [JsonProperty("statusDescription")]
        public string StatusDescription { get; set; }

        [JsonProperty("ytdHazardInsurancePaid")]
        public double? YtdHazardInsurancePaid { get; set; }

        [JsonProperty("ytdInterestAssessed")]
        public double? YtdInterestAssessed { get; set; }

        [JsonProperty("ytdInterestPaidAmount")]
        public double? YtdInterestPaidAmount { get; set; }

        [JsonProperty("ytdPrincipalPaidAmount")]
        public double? YtdPrincipalPaidAmount { get; set; }

        [JsonProperty("ytdMortgageInsuranceAmount")]
        public double? YtdMortgageInsuranceAmount { get; set; }
    }

    public class LoanDataValidationResult
    {
        public string ColumnName { get; set; }
        public string MSPValue { get; set; }
        public string APIValue { get; set; }
        public bool IsMatched { get; set; }
    }
}
