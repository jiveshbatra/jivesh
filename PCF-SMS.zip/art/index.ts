import { IInputs as BaseInputs, IOutputs } from "./generated/ManifestTypes";
import twilio from "twilio";

const twilioAccountSid = "YOUR_TWILIO_ACCOUNT_SID";
const twilioAuthToken = "YOUR_TWILIO_AUTH_TOKEN";

interface ISmsOtpOutputs extends IOutputs {
  smsSent: boolean;
}

interface IInputs extends BaseInputs {
  toPhoneNumber: {
    raw?: string;
  };
  twilioPhoneNumber: {
    raw?: string;
  };
  twilioAccountSid: {
    raw?: string;
  };
  twilioAuthToken: {
    raw?: string;
  };
}

export class art
  implements ComponentFramework.StandardControl<IInputs, IOutputs>
{
  private container: HTMLDivElement;
  private context: ComponentFramework.Context<IInputs>;
  private notifyOutputChanged: () => void;
  private apiClient: twilio.Twilio;

  public init(
    context: ComponentFramework.Context<IInputs>,
    notifyOutputChanged: () => void,
    state: ComponentFramework.Dictionary,
    container: HTMLDivElement
  ): void {
    this.context = context;
    this.notifyOutputChanged = notifyOutputChanged;
    this.container = container;

    this.apiClient = twilio(twilioAccountSid, twilioAuthToken);
  }

  public updateView(context: ComponentFramework.Context<IInputs>): void {
    const sendSmsButton = document.createElement("button");
    sendSmsButton.innerText = "Send SMS OTP";
    sendSmsButton.addEventListener("click", this.sendSmsOtp);

    this.container.innerHTML = "";
    this.container.appendChild(sendSmsButton);
  }

  public getOutputs(): ISmsOtpOutputs {
    return {
      smsSent: true,
    };
  }

  public destroy(): void {}

  private sendSmsOtp = async () => {
    const otp = Math.floor(100000 + Math.random() * 900000).toString();

    const toPhoneNumber = this.context.parameters.toPhoneNumber.raw!;
    await this.apiClient.messages.create({
      from: this.context.parameters.twilioPhoneNumber.raw!,
      to: toPhoneNumber,
      body: `Your OTP code is ${otp}`,
    });

    this.notifyOutputChanged();
  };
}
