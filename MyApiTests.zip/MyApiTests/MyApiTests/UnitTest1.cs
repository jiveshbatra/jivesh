using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using ExcelDataReader;
using Newtonsoft.Json;

namespace MyApiTests
{
    [TestFixture]
    public class ApiTests
    {
        // ---------------------------------------------------------------------
        // Hardcoded API credentials & URLs (for demonstration only).
        // Normally you'd store these in secure variables or a vault.
        // ---------------------------------------------------------------------
        private static readonly string AccessTokenUrl = "https://apimdev.vystarcu.org/authentication-api/v1/token";
        private static readonly string ClientId = "11a38a2b-f702-4ad3-abf7-48a748ff8d8a";
        private static readonly string Secret = "kcf8Q~1XuleSLtmfUS0dAgK8.svOUOwyMomi_chs";
        private static readonly string CoreBankingScope = "api://4fa917c3-9b54-488d-8c8d-fef1ea32ce26/.default";
        private static readonly string CoreBankingEndpointUrl = "https://apimuat.vystarcu.org/core-banking-api/v1";

        /// <summary>
        /// Represents a single row in our Excel file.
        /// </summary>
        public class TestCaseModel
        {
            public string TestCaseID { get; set; }
            public string Endpoint { get; set; }
            public string RequestBody { get; set; }
            public int ExpectedStatusCode { get; set; }
            public string ExpectedBody { get; set; }
        }

        /// <summary>
        /// Reads rows from ApiTests.xlsx and yields them as test cases.
        /// </summary>
        public static IEnumerable<TestCaseModel> GetTestCasesFromExcel()
        {
            // Excel file name/path. Make sure "Copy to Output Directory" is set.
            string excelFileName = "ApiTests.xlsx";
            string excelPath = Path.Combine(TestContext.CurrentContext.TestDirectory, excelFileName);

            // Required by ExcelDataReader for certain encodings / older Excel files
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

            using (var stream = File.Open(excelPath, FileMode.Open, FileAccess.Read))
            using (var reader = ExcelReaderFactory.CreateReader(stream))
            {
                bool isHeaderRow = true;

                // Each row in the first worksheet
                while (reader.Read())
                {
                    // Skip header row
                    if (isHeaderRow)
                    {
                        isHeaderRow = false;
                        continue;
                    }

                    // Safely read cells
                    string testCaseID = reader.GetValue(0)?.ToString() ?? "";
                    string endpoint = reader.GetValue(1)?.ToString() ?? "";
                    string requestBodyStr = reader.GetValue(2)?.ToString() ?? "";
                    string expectedStatusCodeStr = reader.GetValue(3)?.ToString() ?? "200";
                    string expectedBody = reader.GetValue(4)?.ToString() ?? "";

                    if (!int.TryParse(expectedStatusCodeStr, out int expectedStatusCode))
                    {
                        expectedStatusCode = 200; // default
                    }

                    yield return new TestCaseModel
                    {
                        TestCaseID = testCaseID,
                        Endpoint = endpoint,
                        RequestBody = requestBodyStr,
                        ExpectedStatusCode = expectedStatusCode,
                        ExpectedBody = expectedBody
                    };
                }
            }
        }

        /// <summary>
        /// Fetches an access token (client credentials flow) from the AccessTokenUrl.
        /// </summary>
        private static string GetAccessToken()
        {
            using (var client = new HttpClient())
            {
                var postData = new Dictionary<string, string>
                {
                    {"client_id", ClientId},
                    {"client_secret", Secret},
                    {"scope", CoreBankingScope},
                    {"grant_type", "client_credentials"}
                };

                var content = new FormUrlEncodedContent(postData);
                var response = client.PostAsync(AccessTokenUrl, content).Result;
                var responseBody = response.Content.ReadAsStringAsync().Result;

                if (!response.IsSuccessStatusCode)
                {
                    throw new Exception($"Failed to retrieve token. HTTP {response.StatusCode} - {responseBody}");
                }

                // Parse JSON; expected shape: { "access_token": "...", "token_type": "Bearer", ... }
                dynamic tokenJson = JsonConvert.DeserializeObject(responseBody);
                string accessToken = tokenJson.access_token;
                return accessToken;
            }
        }

        /// <summary>
        /// The main test method, run once per Excel row.
        /// </summary>
        [TestCaseSource(nameof(GetTestCasesFromExcel))]
        public void TestApiUsingExcelData(TestCaseModel testCase)
        {
            // 1) Acquire access token
            string token = GetAccessToken();

            // 2) Prepare HTTP client
            using (var client = new HttpClient())
            {
                // We'll set Authorization header with the Bearer token
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                // If the Excel file has a relative endpoint path, you could combine with the base URL:
                // e.g. testCase.Endpoint might be "/accounts" 
                // So your final endpoint might be CoreBankingEndpointUrl + testCase.Endpoint 
                // (Depending on how you store data in Excel.)
                string fullEndpoint = testCase.Endpoint;

                // Create the request body
                var content = new StringContent(testCase.RequestBody, Encoding.UTF8, "application/json");

                // POST the request. (Adjust if you need GET/PUT/DELETE.)
                var response = client.PostAsync(fullEndpoint, content).Result;
                var actualResponseBody = response.Content.ReadAsStringAsync().Result;
                var actualStatusCode = (int)response.StatusCode;

                // 3) Assert the status code matches expected
                Assert.AreEqual(
                    testCase.ExpectedStatusCode,
                    actualStatusCode,
                    $"[TestCaseID: {testCase.TestCaseID}] - Status code mismatch."
                );

                // 4) Assert the body contains an expected substring
                Assert.IsTrue(
                    actualResponseBody.Contains(testCase.ExpectedBody),
                    $"[TestCaseID: {testCase.TestCaseID}] - ExpectedBody substring not found. " +
                    $"Expected: {testCase.ExpectedBody}\nActual: {actualResponseBody}"
                );
            }
        }
    }
}
