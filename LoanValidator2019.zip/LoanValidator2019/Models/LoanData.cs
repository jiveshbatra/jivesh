﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoanValidatorApp.Models
{
    public class LoanData
    {
        public string AccountNumber { get; set; }
        public string AccountHolderMemberNumber { get; set; }
        public string AccountHolderName { get; set; }
        public string JointHolderMemberNumber { get; set; }
        public string JointHolderName { get; set; }
        public string OpenDate { get; set; }
        public string AccountType { get; set; }
        public string AccountSubType { get; set; }
        public double AccruedLateChargeBalance { get; set; }
        public double CurrentBalance { get; set; }
        public double EscrowBalance { get; set; }
        public double InterestRate { get; set; }
        public string MaturityDate { get; set; }
        public int OriginalLoanTerm { get; set; }
        public double OriginalLoanAmount { get; set; }
        public double PaymentAccidentHealthAmount { get; set; }
        public double PaymentBuydownSubsidyAmount { get; set; }
        public double PaymentCountyTaxAmount { get; set; }
        public double PaymentHazardAmount { get; set; }
        public double PaymentHudSubsidyAmount { get; set; }
        public double PaymentLienAmount { get; set; }
        public double PaymentLifeAmount { get; set; }
        public double PaymentMiscellaneousAmount { get; set; }
        public double PaymentMortgageInsuranceAmount { get; set; }
        public string PaymentNextDueDate { get; set; }
        public double PaymentPrincipalAndInterest { get; set; }
        public double PaymentTotalAmountDue { get; set; }
        public double PointsPaid { get; set; }
        public double PreviousPaymentEscrowAmount { get; set; }
        public double PreviousPaymentInterestAmount { get; set; }
        public double PreviousPaymentPrincipalAmount { get; set; }
        public string PreviousPaymentReceivedDate { get; set; }
        public double PreviousPaymentTotalAmount { get; set; }
        public double PreviousYearInterestOnEscrow { get; set; }
        public double PreviousYearInterestPaid { get; set; }
        public double PreviousYearPrincipalPaid { get; set; }
        public double PreviousYearTaxesPaid { get; set; }
        public string PropertyType { get; set; }
        public int RemainingLoanTerm { get; set; }
        public string StatusCode { get; set; }
        public string StatusDescription { get; set; }
        public double YtdHazardInsurancePaid { get; set; }
        public double YtdInterestAssessed { get; set; }
        public double YtdInterestPaidAmount { get; set; }
        public double YtdPrincipalPaidAmount { get; set; }
        public double YtdMortgageInsuranceAmount { get; set; }
    }

    public class LoanDataValidationResult
    {
        public string ColumnName { get; set; }
        public string MSPValue { get; set; }
        public string APIValue { get; set; }
        public bool IsMatched { get; set; }
    }
}
