﻿using RestSharp;
using Newtonsoft.Json;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using System.Configuration;
using Newtonsoft.Json.Linq;
using LoanValidatorApp.Models;

namespace LoanValidatorApp.Helpers
{
    public class ApiService
    {
        private string _accessToken;
        string clientId = ConfigurationManager.AppSettings["AuthConfig:ClientId"];
        string clientSecret = ConfigurationManager.AppSettings["AuthConfig:ClientSecret"];
        string scope = ConfigurationManager.AppSettings["AuthConfig:scope"];
        string tokenEndpoint = ConfigurationManager.AppSettings["AuthConfig:TokenEndpoint"];
        string loanInfoEndpoint = ConfigurationManager.AppSettings["AuthConfig:LoanInfoEndpoint"];
        public ApiService()
        {
        }

        public async Task<string> GetAccessTokenAsync()
        {
            var client = new RestClient(tokenEndpoint);
            var request = new RestRequest(tokenEndpoint, Method.Post)
                .AddHeader("Content-Type", "application/x-www-form-urlencoded")
                .AddParameter("client_id", clientId)
                .AddParameter("client_secret", clientSecret)
                 .AddParameter("scope", scope)
                .AddParameter("grant_type", "client_credentials");

            var response = await client.PostAsync<TokenResponse>(request);
            return _accessToken = response?.access_token;
        }
        //"MM/DD/YYYY"
        public async Task<LoanData> GetLoanInfoAsync(string loanNumber)
        {
            var client = new RestClient(loanInfoEndpoint);
            var request = new RestRequest()
                .AddHeader("Authorization", $"Bearer {_accessToken}")
                .AddHeader("VyStar-Account-Number", loanNumber);

            var response = await client.GetAsync(request);
            return JsonConvert.DeserializeObject<LoanData>(response.Content);
        }

        private class TokenResponse
        {
            public string access_token { get; set; }
        }
    }
}