﻿using LoanValidatorApp.Models;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using static System.Windows.Forms.DataFormats;

namespace LoanValidatorApp.Helpers
{
    public static class ExcelHelper
    {
        private static readonly Dictionary<string, string> ColumnMapping = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
               {
                { "VyStarAccountNumber", "accountNumber" },
                { "accountHolderMemberNumber/CIF", "accountHolderMemberNumber" },
                { "accountHolderName/Borrower", "accountHolderName" },
                { "accountNumber", "accountNumber" },
                { "accountTypeCode", "accountTydpe" },
                { "accountSubType (Product", "accountSubType" },
                { "closeDate", "closeDate" },
                { "currentBalance", "currentBalance" },
                { "escrowBalance", "escrowBalance" },
                { "interestRate", "interestRate" },
                { "jointHolderMemberNumber", "jointHolderMemberNumber" },
                { "jointHolderName", "jointHolderName" },
                { "maturityDate", "maturityDate" },
                { "openDate", "openDate" },
                { "originalLoanTerm", "originalLoanTerm" },
                { "originalLoanAmount", "originalLoanAmount" },
                { "remainingLoanTerm", "remainingLoanTerm" },
                { "status", "statusCode" },
                { "Status Description", "statusDescription" },
                { "paymentTotalAmount Due", "paymentTotalAmountDue" },
                { "previousYearTaxesPaid", "previousYearTaxesPaid" },
                { "previousYearInterestPaid", "previousYearInterestPaid" },
                { "previousYearInterestOnEscrow", "previousYearInterestOnEscrow" },
                { "previousYearPrincipalPaid", "previousYearPrincipalPaid" },
                { "ytdInterestAssessed", "ytdInterestAssessed" },
                { "ytdInterestPaidAmount", "ytdInterestPaidAmount" },
                { "ytdHazardInsurancePaid", "ytdHazardInsurancePaid" },
                { "ytdMortgageInsuranceAmount", "ytdMortgageInsuranceAmount" },
                { "paymentPrincipalAndInterest", "paymentPrincipalAndInterest" },
                { "paymentNextDueDate", "paymentNextDueDate" },
                { "paymentCountyTaxAmount", "paymentCountyTaxAmount" },
                { "paymentHazardAmount", "paymentHazardAmount" },
                { "paymentLienAmount", "paymentLienAmount" },
                { "paymentOverShortAmount", "paymentOverShortAmount" },
                { "paymentMortgageInsuranceAmount", "paymentMortgageInsuranceAmount" },
                { "paymentLifeAmount", "paymentLifeAmount" },
                { "paymentAccidentHealthAmount", "paymentAccidentHealthAmount" },
                { "paymentHudSubsidyAmount", "paymentHudSubsidyAmount" },
                { "paymentMiscellaneousAmount", "paymentMiscellaneousAmount" },
                { "paymentBuydownSubsidyAmount", "paymentBuydownSubsidyAmount" },
                { "previousPaymentTaxAmount", "previousPaymentTaxAmount" },
                { "previousPaymentHazardAmount", "previousPaymentHazardAmount" },
                { "previousPaymentReceivedDate", "previousPaymentReceivedDate" },
                { "previousPaymentPrincipalAmount", "previousPaymentPrincipalAmount" },
                { "previousPaymentEscrowAmount", "previousPaymentEscrowAmount" },
                { "previousPaymentTotalAmount", "previousPaymentTotalAmount" },
                { "propertyType", "propertyType" },
                { "AccruedLateChargeBalance", "accruedLateChargeBalance" },
                { "PointsPaidByBorrowerAmount", "pointsPaid" },
            };
        static ExcelHelper()
        {
            // Set EPPlus license context (required for non-commercial use)
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
        }
        public static bool LoanSheetExists(string filePath, string loanNumber)
        {
            using (var package = new ExcelPackage(new FileInfo(filePath)))
            {
                return package.Workbook.Worksheets.Any(ws =>
                    ws.Name.Equals(loanNumber, StringComparison.OrdinalIgnoreCase)
                );
            }
    }

        public static void UpdateValidationResults(string filePath, string loanNumber, List<LoanDataValidationResult> validationResults)
        {
            using (var package = new ExcelPackage(new FileInfo(filePath))) { 
                var sheet = package.Workbook.Worksheets[loanNumber];
            if (sheet == null) return;

            const int fieldRow = 1;  // Field names in row 1
            const int resultRow = 4; // Validation results in row 4
            const int apiValueRow = 6; // API values in row 6

            for (int col = 2; col <= sheet.Dimension.End.Column; col++)
            {
                string field = sheet.Cells[fieldRow, col].Text?.Trim();
                if (string.IsNullOrEmpty(field)) continue;

                // Map Excel field to API property name
                string apiPropertyName = GetMappedApiPropertyName(field);

                var validationResult = validationResults.FirstOrDefault(v => v.ColumnName.Equals(apiPropertyName, StringComparison.OrdinalIgnoreCase));

                if (validationResult != null)
                {
                    // Update match result in row 4
                    var resultCell = sheet.Cells[resultRow, col];
                    resultCell.Value = validationResult.IsMatched ? "Matched" : "Unmatched";
                    resultCell.Style.Fill.PatternType = ExcelFillStyle.Solid;
                    resultCell.Style.Fill.BackgroundColor.SetColor(validationResult.IsMatched ? Color.Green : Color.Red);

                    // Update API value in row 6
                    var apiValueCell = sheet.Cells[apiValueRow, col];
                    apiValueCell.Value = !string.IsNullOrEmpty(validationResult.APIValue) ? validationResult.APIValue : "Not Entered";
                }
            }
            package.Save();
            }
        }


        private static string GetMappedApiPropertyName(string field)
        {
            return ColumnMapping.TryGetValue(field, out string apiPropertyName)
                ? apiPropertyName
                : field;
        }
        public static Dictionary<string, string> GetFieldsAndMspValues(string filePath, string loanNumber)
        {
            var fields = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            using (var package = new ExcelPackage(new FileInfo(filePath))) { 
                var sheet = package.Workbook.Worksheets[loanNumber];

            if (sheet == null) return fields;

            const int fieldRow = 1;   // Column A: "Field"
            const int mspValueRow = 2; // Column B: "MSP Value"

            for (int col = 2; col <= sheet.Dimension.End.Column; col++)
            {
                string field = sheet.Cells[fieldRow, col].Text?.Trim();
                string mspValue = sheet.Cells[mspValueRow, col].Text?.Trim();

                if (!string.IsNullOrEmpty(field))
                {
                    if (ColumnMapping.TryGetValue(field, out string apiPropertyName))
                    {
                        fields[apiPropertyName] = ConvertToStandardDateFormat(apiPropertyName, mspValue);
                    }
                    else
                    {
                        fields[field] = ConvertToStandardDateFormat(field, mspValue);
                    }
                }
            }
            return fields;
          }
        }


        public static string ConvertToStandardCurrencyFormat(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return null;

            // Remove dollar signs and commas
            value = value.Replace("$", "").Replace(",", "").Trim();

            // Ensure it's a valid numeric value
            if (decimal.TryParse(value, out decimal result))
                return result.ToString(); // Return as a string for comparison

            return null; // If not a valid number, return null
        }

        private static string ConvertToStandardDateFormat(string apiPropertyName, string input)
        {
            if (string.IsNullOrWhiteSpace(input)) return input; // Keep null/empty values as-is
            if (!apiPropertyName.ToLower().Contains("date")) return input;

            // Try parsing as a numeric serial date (Excel format)
            if (double.TryParse(input, out double serialDate))
            {
                if (serialDate >= 1 && serialDate <= 2958465) 
                {
                    return DateTime.FromOADate(serialDate).ToString("yyyy-MM-dd");
                }
                else
                {
                    return input;
                }
            }

            // Try parsing common date formats
            string[] dateFormats = { "M/d/yyyy", "M/dd/yyyy", "MM/d/yyyy", "MM/dd/yyyy" };
            DateTime parsedDate;

            if (DateTime.TryParseExact(input, dateFormats, CultureInfo.InvariantCulture, DateTimeStyles.None, out parsedDate))
            {
                return parsedDate.ToString("yyyy-MM-dd"); // Convert to ISO format
            }

            return input; // Return as-is if it's not a recognizable date
        }

        public static List<string> GetLoanNumbers(string filePath)
        {
            var loanNumbers = new List<string>();
            using (var package = new ExcelPackage(new FileInfo(filePath))) { 
            var mainSheet = package.Workbook.Worksheets
                .FirstOrDefault(ws => ws.Name.Equals("TEST Data Selections", System.StringComparison.OrdinalIgnoreCase));

            if (mainSheet == null) return loanNumbers;

            // Find "LOAN NUMBER" column
            int loanNumberCol = 1;
            for (; loanNumberCol <= mainSheet.Dimension.End.Column; loanNumberCol++)
            {
                if (mainSheet.Cells[1, loanNumberCol].Text.Equals("LOAN NUMBER", System.StringComparison.OrdinalIgnoreCase))
                    break;
            }

            // Collect loan numbers
            for (int row = 2; row <= mainSheet.Dimension.End.Row; row++)
            {
                string loanNumber = mainSheet.Cells[row, loanNumberCol].Text?.Trim();
                if (!string.IsNullOrEmpty(loanNumber))
                    loanNumbers.Add(loanNumber);
            }
            return loanNumbers;
            }
        }

        public static void UpdateLoanStatus(string filePath, string loanNumber, bool isMatched)
        {
            using (var package = new ExcelPackage(new FileInfo(filePath))) { 
                var mainSheet = package.Workbook.Worksheets
                    .FirstOrDefault(ws => ws.Name.Equals("TEST Data Selections", System.StringComparison.OrdinalIgnoreCase));

            if (mainSheet == null) return;

            // Find "LOAN NUMBER" column
            int loanNumberCol = 1;
            for (; loanNumberCol <= mainSheet.Dimension.End.Column; loanNumberCol++)
            {
                if (mainSheet.Cells[1, loanNumberCol].Text.Equals("LOAN NUMBER", System.StringComparison.OrdinalIgnoreCase))
                    break;
            }

            // Find loan number row
            for (int row = 2; row <= mainSheet.Dimension.End.Row; row++)
            {
                if (mainSheet.Cells[row, loanNumberCol].Text == loanNumber)
                {
                    var cell = mainSheet.Cells[row, loanNumberCol];
                    cell.Style.Fill.PatternType = ExcelFillStyle.Solid;
                    cell.Style.Fill.BackgroundColor.SetColor(
                        isMatched ? System.Drawing.Color.Green : System.Drawing.Color.Red
                    );
                    package.Save();
                    break;
                }
            }
            }
        }
    }
}